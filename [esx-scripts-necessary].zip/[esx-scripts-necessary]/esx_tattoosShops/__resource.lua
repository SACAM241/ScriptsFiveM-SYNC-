client_script 'client/tattoosList/list.lua'
client_script 'client/config.lua'
client_script 'client/client.lua'


server_script '@mysql-async/lib/MySQL.lua'
server_script 'server/server.lua'