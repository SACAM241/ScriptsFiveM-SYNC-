Locales ['br'] = {

    ['valid_purchase'] = 'Validar esta compra?',
    ['yes'] = 'Sim, por favor',
    ['no'] = 'Não, obrigado',
    ['not_enough_money'] = 'Você não tem dinheiro suficiente',
    ['press_access'] = 'Pressione ~INPUT_CONTEXT~ para acessar o menu',
    ['masks_blip'] = 'Máscaras',
    ['no_mask'] = 'Você não tem máscara',
    ['you_paid'] = 'você pagou ',

}