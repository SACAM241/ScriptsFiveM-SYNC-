USE `essentialmode`;

INSERT INTO `datastore` (name, label, shared) VALUES
  ('user_mask','Masque',0)
;
