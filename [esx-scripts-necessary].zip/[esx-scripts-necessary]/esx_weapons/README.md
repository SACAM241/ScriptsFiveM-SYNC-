# fxserver-esx_weapons

FXServer ESX WEAPONS


[INSTALLATION]

1) CD in your resources/[esx] folder

3) Import esx_weapons.sql in your database

4) Add this in your server.cfg :

```
start esx_weapons
```


[FEATURES]

* WEAPONS
  * Weapons as items
  * Components as items with MK II weapons compatibility
  * Tints as items with MK II weapons compatibility
  * Component tints for MK II weapons
  * Varmod / Camo for standard + MK II weapons