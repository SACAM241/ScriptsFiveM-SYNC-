# esx_prw_tatooshop
NativeUI esx_tatooshop

You have to rename your table or import the sql !!

only work with this version https://github.com/FrazzIe/NativeUILua

If you want to adapt it to NativeUI-Reloaded do it yourself
