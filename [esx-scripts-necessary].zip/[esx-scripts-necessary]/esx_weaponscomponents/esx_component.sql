INSERT INTO `items` (name, label) VALUES
	('silence_pistol', 'Silencieux Pistolet'),
	('silence_pistol50',  'Silencieux cal.50'),
	('silence_sniperrifle',  'Silencieux SniperRifle'),
	('advancedscoped_sniperrifle',  'Lunette de Visée'),
	('flashlight_assaultsmg',  'Lampe AssaultSMG'),
	('clip_heavypistol',  'Chargeur Heavy Pistol'),
	('supp_heavypistol',  'Silençieux Heavy Pistol'),
	('scope_smg',  'Lunette SMG'),
	('lowrider_smg',  'LowRider SMG'),
	('supp_smg',  'Silençieux SMG'),
	('grip_smg',  'Poignée SMG'),
	('flash_cp',  'Lampe Glock-17'),
	('supp_cp',  'Silençieux Glock-17'),
	('lowrider_cp',  'LowRider Glock-17'),
	('clip_sc',  'Chargeur SCAR'),
	('grip_sc',  'Poignée SCAR'),
	('clip_gus',  'Chargeur Gusenberg'),
	('supp_sc',  'Silençieux SCAR');




















