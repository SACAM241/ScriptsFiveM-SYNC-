description 'esx_component'

version '1.0.0'

server_scripts {
  'server/main.lua'
}

client_scripts {
  'client/main.lua'
}