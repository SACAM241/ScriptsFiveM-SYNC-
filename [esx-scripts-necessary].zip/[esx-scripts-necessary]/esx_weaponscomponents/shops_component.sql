INSERT INTO `shops` (`id`, `name`, `item`, `price`) VALUES

(18, 'UpgradeArmes', 'silence_pistol', 2500),
(19, 'UpgradeArmes', 'silence_pistol50', 2500),
(20, 'UpgradeArmes', 'clip_heavypistol', 2500),
(21, 'UpgradeArmes', 'supp_heavypistol', 2500),
(21, 'UpgradeArmes', 'clip_gus', 2500),

(22, 'UpgradeArmesPolice', 'advancedscoped_sniperrifle', 2500),
(23, 'UpgradeArmesPolice', 'silence_sniperrifle', 2500),

(24, 'UpgradeArmesPolice', 'flashlight_assaultsmg', 2500),
(25, 'UpgradeArmesPolice', 'scope_smg', 2500),
(26, 'UpgradeArmesPolice', 'lowrider_smg', 2500),
(27, 'UpgradeArmesPolice', 'supp_smg', 2500),
(28, 'UpgradeArmesPolice', 'grip_smg', 2500),

(29, 'UpgradeArmesPolice', 'flash_cp', 2500),
(30, 'UpgradeArmesPolice', 'supp_cp', 2500),
(31, 'UpgradeArmesPolice', 'lowrider_cp', 2500),

(32, 'UpgradeArmesPolice', 'clip_sc', 2500),
(33, 'UpgradeArmesPolice', 'grip_sc', 2500),
(34, 'UpgradeArmesPolice', 'supp_sc', 2500);
















