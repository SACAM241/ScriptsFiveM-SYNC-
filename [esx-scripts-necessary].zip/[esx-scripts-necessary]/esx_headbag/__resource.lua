resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'HEAD BAG SCRIPT'

author 'BicuS - FAMERP.PL'

version '1.0.1'

client_scripts {
	'client.lua'
}

server_scripts {
    'server.lua'
}

ui_page('index.html') --HEAD BAG IMAGE

files {
    'index.html'
}