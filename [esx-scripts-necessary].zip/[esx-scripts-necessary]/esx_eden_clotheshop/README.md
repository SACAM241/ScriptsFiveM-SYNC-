# fxserver-esx_eden_clotheshop
FXServer ESX ClotheShop Modified by Eden-RP

If you have any comment or suggested PM me on discord : Solaris#6632

[REQUIREMENTS]

- esx_skin => https://github.com/FXServer-ESX/fxserver-esx_skin

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/ESX-PUBLIC/esx_eden_clotheshop.git clotheshop
```
3) Add this in your server.cfg :

```
start esx_eden_clotheshop
```

[SCREEN]

-- EN : https://img15.hostingpics.net/pics/348886Capturedcran20171202005329.png

-- FR : https://img15.hostingpics.net/pics/499448Capturedcran20171130214439.png

