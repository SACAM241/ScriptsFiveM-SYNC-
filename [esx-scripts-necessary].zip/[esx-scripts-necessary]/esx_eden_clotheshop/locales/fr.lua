Locales['fr'] = {

	['valid_this_purchase'] = 'valider cet achat ?',
	['yesdresseing'] = 'Sauvegarder dans la grade robe',
	['yes'] = 'Payer',
	['no'] = 'Annuler',
	['name_outfit'] = 'nom de la tenue ?',
	['not_enough_money'] = 'vous n\'avez pas assez d\'argent',
	['press_menu'] = 'appuyez sur ~INPUT_CONTEXT~ pour accéder au menu',
	['clothes'] = 'vêtements',
	['you_paid'] = 'vous avez payé ~g~$',
	['save_in_dressing'] = 'donner un nom à votre tenue ?',
	['shop_clothes'] = 'magasin de vêtements',
	['player_clothes'] = 'changer tenue - garde robe',
	['shop_main_menu'] = 'bienvenue ! que souhaite tu ?',
	['saved_outfit'] = 'votre tenue à bien été sauvegardé dans la garde robe. Merci de votre visite !',
	['loaded_outfit'] = 'vous avez bien ~g~récupéré~w~ la tenue de votre garde robe. Merci de votre visite !',
	['suppr_cloth'] = 'supprimer tenue - garde robe',
	['supprimed_cloth'] = 'cette tenue a bien été ~r~supprimé~w~ de votre garde robe'

}
