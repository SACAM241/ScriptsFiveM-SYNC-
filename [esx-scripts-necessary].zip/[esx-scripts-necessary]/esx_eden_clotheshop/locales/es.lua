Locales['es'] = {

	['valid_this_purchase'] = '¿Validar esta compra?',
	['yes'] = 'Si',
	['no'] = 'No',
	['name_outfit'] = 'Nombre del traje ?',
	['not_enough_money'] = 'No tienes suficiente dinero',
	['press_menu'] = 'Presiona ~INPUT_CONTEXT~ para acceder al menú',
	['clothes'] = 'Ropa',
	['you_paid'] = 'Has pagado €',
	['save_in_dressing'] = '¿Quieres darle un nombre a tu vestuario?',
}
