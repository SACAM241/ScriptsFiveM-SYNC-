Locales['en'] = {

	['valid_this_purchase'] = 'validate this purchase?',
	['yes'] = 'yes',
	['no'] = 'no',
	['name_outfit'] = 'name of the outfit?',
	['not_enough_money'] = 'you do not have enough money',
	['press_menu'] = 'press ~INPUT_CONTEXT~ to access the menu',
	['clothes'] = 'clothes',
	['you_paid'] = 'you paid $',
	['save_in_dressing'] = 'Do you want to give a name to your outfit ?',
	['shop_clothes'] = 'clothing store',
	['player_clothes'] = 'change clothes - dressing-room',
	['shop_main_menu'] = 'welcome ! what do you want to do ?',
	['saved_outfit'] = 'your outfit has been saved in your dressing-room. Thank you for your visit !',
	['loaded_outfit'] = 'you have recovered the outfit of your dressing-room. Thank you for your visit !',
	['suppr_cloth'] = 'delete outfit - dressing-room',
	['supprimed_cloth'] = 'this outfit has been deleted of your dressing-room'

}
