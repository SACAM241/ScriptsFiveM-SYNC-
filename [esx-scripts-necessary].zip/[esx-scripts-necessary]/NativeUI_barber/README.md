# esx_barbershop
Im releasing this script because an asshole sold it

* Converted to NativeUI


* No fcking screenshot test it and enjoy
