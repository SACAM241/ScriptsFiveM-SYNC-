License (custom license)

You can use this library in your own resources, you can edit this library if you want to add features. Feel free to PR them.

You can use this library in your own public using the SubModule github here is a very simple tool to use them https://support.gitkraken.com/working-with-repositories/submodules/

You can host re-releases of this library , but ONLY as a FORK created via GitHub. If it's not a forked repo, then the release will be taken down by DMCA request.

It's very simple, don't steal this library and try to take credit.
