# What is UIMenu folder

The `UIMenu' folder contains the main files related to the generation and creation of the interaction menus typical of GTA:O.