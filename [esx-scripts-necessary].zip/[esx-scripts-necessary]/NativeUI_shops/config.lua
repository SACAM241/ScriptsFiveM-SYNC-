Config = {}
Config.DrawDistance = 15
Config.Size         = {x = 1.5, y = 1.5, z = 1.5}
Config.Color        = {r = 0, g = 255, b = 42}
Config.Type         = 25

Config.PriceEau = 20
Config.PriceSoda = 500
Config.PriceCocaCola = 45

Config.PricePain = 20
Config.PriceSandwich = 35
Config.PriceCupCake = 35
Config.PriceChocolat = 40
Config.PriceHamburger = 55
Config.PriceHamburgerPlate = 55
Config.PriceBreadSaucisson = 55
Config.PriceBeef = 500

Config.PriceGPS = 500
Config.PriceTel = 1500
Config.PriceSim = 500