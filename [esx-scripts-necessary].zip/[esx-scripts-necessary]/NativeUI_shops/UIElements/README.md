# What is UIElements folder

The `UIElements` folder contains the main files for the realization of NativeUILua-Reloaded, it allows to generate all the so visual according to the resolution of the screens
 