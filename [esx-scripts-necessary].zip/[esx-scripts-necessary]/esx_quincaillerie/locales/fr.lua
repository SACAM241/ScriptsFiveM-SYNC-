Locales['fr'] = {

	['quincaillerie'] = 'quincaillerie',
	['quincailleries'] = 'quincailleries',
	['press_menu'] = '~INPUT_CONTEXT~ Pour accéder à la ~b~Quincaillerie',
	['bought'] = 'vous avez acheté ~b~1x ',
	['not_enough'] = '~r~vous n\'avez pas assez~s~ d\'argent',
	
}
