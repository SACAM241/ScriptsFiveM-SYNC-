# fxserver-esx_shops
FXServer ESX Shops

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/FXServer-ESX/fxserver-esx_shops esx_shops
```
3) Import esx_shops.sql in your database
4) Add this in your server.cfg :

```
start esx_shops
```
