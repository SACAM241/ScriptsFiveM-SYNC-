Config        = {}
Config.Locale = 'fr'

Config.EnableESXIdentity = true -- only turn this on if you are using esx_identity and want to use RP names
Config.OnlyFirstname     = true

---------------------------------
--- Copyright by ikNox#6088 ---
---------------------------------