Locales['sv'] = {
	['ooc_help'] = 'skicka ett meddelande som inte kopplat till din karaktär',
	['ooc_prefix'] = 'OOC | %s',
	['twt_help'] = 'skicka en tweet',
	['twt_prefix'] = '^0[^4Twitter^0] (^5@%s^0)',
	['me_help'] = 'skriv en händelse, t.ex \'visar körkort\'',
	['me_prefix'] = 'jag | %s',
	['do_help'] = 'rollspelinformation', --TODO: check translation
	['do_prefix'] = 'do | %s',
	['news_help'] = 'meddela en nyhet (missbruka inte)',
	['news_prefix'] = 'TV4 Stockholm',
	['ooc_argument_name'] = 'meddelande',
	['ooc_argument_help'] = 'det meddelandet du vill skicka',
	['ooc_unknown_command'] = '^3%s^0 är inte ett giltigt kommando!',
}
