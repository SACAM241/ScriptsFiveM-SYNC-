resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a5811d8f9'

description 'Entity Sync'

server_scripts {
	'server/main.lua'
}

client_scripts {
	'client/main.lua',
}
