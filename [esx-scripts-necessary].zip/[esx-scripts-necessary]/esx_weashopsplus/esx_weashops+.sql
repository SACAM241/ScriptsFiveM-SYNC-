USE `essentialmode`;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('weapon', 'Weapon Level: One'),
	('weapon2', 'Weapon Level: Two'),
	('weapon3', 'Weapon Level: Three');
